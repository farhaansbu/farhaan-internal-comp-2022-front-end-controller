console.log("Write your JavaScript code here!");

/**
 *  the function `sendToBot(command: string)` 
 *  will relay anything you want to your "controls.py" Python script.
 * 	Try it! Copy this code onto line 8: document.body.addEventListener(`click`, () => sendToBot("SBRT"));
 *  It should let you sent "SBRT" to your bot every time you click.
 */